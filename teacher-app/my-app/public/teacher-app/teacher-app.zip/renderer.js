const { ipcRenderer } = require('electron');
const Store = require('electron-store');
const store = new Store();

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const mainScreen = document.getElementById('main-screen');
const loginForm = document.getElementById('login-form');
const teacherEmailElement = document.getElementById('teacherEmail');
const logoutBtn = document.getElementById('logoutBtn');
const navButtons = document.querySelectorAll('.nav-btn');
const sections = document.querySelectorAll('.section');
const startRecordingBtn = document.getElementById('startRecording');
const stopRecordingBtn = document.getElementById('stopRecording');
const createSummaryBtn = document.getElementById('createSummary');
const recordingsList = document.getElementById('recordingsList');
const summariesList = document.getElementById('summariesList');

// Recording state
let mediaRecorder = null;
let recordingChunks = [];
let recordingTimer = null;
let recordingStartTime = null;
let audioChunks = [];
let currentRecording = null;

// Event Listeners
loginForm.addEventListener('submit', handleLogin);
logoutBtn.addEventListener('click', handleLogout);
navButtons.forEach(btn => btn.addEventListener('click', handleNavigation));
startRecordingBtn.addEventListener('click', startRecording);
stopRecordingBtn.addEventListener('click', stopRecording);
createSummaryBtn.addEventListener('click', showCreateSummaryForm);

// Check for existing session
checkSession();

async function checkSession() {
    const token = store.get('userToken');
    if (token) {
        showMainScreen();
        loadUserData();
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const name = document.getElementById('name')?.value || 'Teacher';

    try {
        console.log('Attempting login for:', email);
        const result = await ipcRenderer.invoke('login', { email, password, name });
        console.log('Login result:', result);
        
        if (result.success) {
            console.log('Login successful, showing main screen');
            showMainScreen();
            await loadUserData();
        } else {
            console.error('Login failed:', result.error);
            alert(result.error || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert(`Login failed: ${error.message || 'Unknown error'}`);
    }
}

function handleLogout() {
    store.delete('userToken');
    store.delete('userEmail');
    store.delete('userName');
    showLoginScreen();
}

function handleNavigation(e) {
    const section = e.target.dataset.section;
    
    // Update active button
    navButtons.forEach(btn => btn.classList.remove('active'));
    e.target.classList.add('active');
    
    // Show selected section
    sections.forEach(s => {
        s.classList.remove('active');
        if (s.id === `${section}-section`) {
            s.classList.add('active');
        }
    });
}

function showScreen(screenId) {
    const screens = document.querySelectorAll('.screen');
    screens.forEach(screen => {
        screen.classList.add('hidden');
        if (screen.id === `${screenId}-screen`) {
            screen.classList.remove('hidden');
        }
    });
}

function showLoginScreen() {
    loginScreen.classList.remove('hidden');
    mainScreen.classList.add('hidden');
}

function showMainScreen() {
    loginScreen.classList.add('hidden');
    mainScreen.classList.remove('hidden');
}

async function loadUserData() {
    const email = store.get('userEmail');
    const name = store.get('userName');
    if (!email) {
        console.log('No email found in store, showing login screen');
        showLoginScreen();
        return;
    }

    console.log('Loading user data for:', email);
    teacherEmailElement.textContent = `${name} (${email})`;
    
    try {
        // Load recordings
        console.log('Loading recordings...');
        const recordings = await ipcRenderer.invoke('get-recordings', email);
        if (!recordings) {
            throw new Error('Failed to load recordings');
        }
        console.log('Recordings loaded:', recordings.length);
        renderRecordings(recordings);
        
        // Load summaries
        console.log('Loading summaries...');
        const summaries = await ipcRenderer.invoke('get-summaries', email);
        if (!summaries) {
            throw new Error('Failed to load summaries');
        }
        console.log('Summaries loaded:', summaries.length);
        renderSummaries(summaries);
    } catch (error) {
        console.error('Error loading user data:', error);
        alert(`Failed to load data: ${error.message || 'Unknown error'}`);
        // If we can't load data, we should probably log out
        handleLogout();
    }
}

async function startRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];

        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            const teacherEmail = store.get('userEmail');
            const recordingName = `Recording_${new Date().toISOString()}`;
            
            const result = await ipcRenderer.invoke('save-recording', {
                teacherEmail,
                recordingData: await blobToBase64(audioBlob),
                name: recordingName
            });

            if (result.success) {
                await loadRecordings(teacherEmail);
            }
        };

        mediaRecorder.start();
        startRecordingBtn.disabled = true;
        stopRecordingBtn.disabled = false;
    } catch (error) {
        console.error('Error starting recording:', error);
    }
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        startRecordingBtn.disabled = false;
        stopRecordingBtn.disabled = true;
    }
}

function startRecordingTimer() {
    recordingTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
        document.getElementById('recording-timer').textContent = formatTime(elapsed);
    }, 1000);
}

function stopRecordingTimer() {
    clearInterval(recordingTimer);
    document.getElementById('recording-timer').textContent = '';
}

function updateRecordingUI(isRecording) {
    document.getElementById('start-recording-btn').disabled = isRecording;
    document.getElementById('stop-recording-btn').disabled = !isRecording;
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

async function saveRecording(blob) {
    try {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = async () => {
            const recordingData = {
                data: reader.result,
                timestamp: new Date().toISOString(),
                duration: Math.floor((Date.now() - recordingStartTime) / 1000)
            };
            await ipcRenderer.invoke('saveRecording', recordingData);
            loadUserData(); // Reload recordings list
        };
    } catch (error) {
        console.error('Error saving recording:', error);
        alert('Failed to save recording');
    }
}

function renderClasses(classes) {
    const classesList = document.getElementById('classes-list');
    classesList.innerHTML = classes.map(cls => `
        <div class="class-item">
            <h3>${cls.name}</h3>
            <div class="class-info">
                <span>Code: ${cls.code}</span>
                <span>${cls.students.length} Students</span>
            </div>
        </div>
    `).join('');
}

function renderRecordings(recordings) {
    recordingsList.innerHTML = recordings.map(recording => `
        <div class="recording-item">
            <div class="recording-info">
                <span class="recording-name">${recording.name}</span>
                <span class="recording-date">${new Date(recording.timestamp).toLocaleString()}</span>
            </div>
            <button onclick="playRecording('${recording.id}')">Play</button>
        </div>
    `).join('');
}

function renderSummaries(summaries) {
    summariesList.innerHTML = summaries.map(summary => `
        <div class="summary-item">
            <div class="summary-info">
                <span class="summary-name">${summary.name}</span>
                <span class="summary-date">${new Date(summary.timestamp).toLocaleString()}</span>
            </div>
            <div class="summary-content">${summary.content}</div>
        </div>
    `).join('');
}

function showCreateClassForm() {
    // Implementation for creating a new class
}

function showCreateSummaryForm() {
    // Implementation for creating a new summary
}

async function loadRecordings(teacherEmail) {
    const recordings = await ipcRenderer.invoke('get-recordings', teacherEmail);
    recordingsList.innerHTML = recordings.map(recording => `
        <div class="recording-item">
            <div class="recording-info">
                <span class="recording-name">${recording.name}</span>
                <span class="recording-date">${new Date(recording.timestamp).toLocaleString()}</span>
            </div>
            <button onclick="playRecording('${recording.id}')">Play</button>
        </div>
    `).join('');
}

async function loadSummaries(teacherEmail) {
    const summaries = await ipcRenderer.invoke('get-summaries', teacherEmail);
    summariesList.innerHTML = summaries.map(summary => `
        <div class="summary-item">
            <div class="summary-info">
                <span class="summary-name">${summary.name}</span>
                <span class="summary-date">${new Date(summary.timestamp).toLocaleString()}</span>
            </div>
            <div class="summary-content">${summary.content}</div>
        </div>
    `).join('');
}

async function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

// Navigation
navButtons.forEach(button => {
    button.addEventListener('click', () => {
        const section = button.dataset.section;
        
        // Update active button
        navButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Show selected section
        sections.forEach(s => {
            s.classList.remove('active');
            if (s.id === `${section}-section`) {
                s.classList.add('active');
            }
        });
    });
});

// Summary functionality
createSummaryBtn.addEventListener('click', async () => {
    const teacherEmail = store.get('userEmail');
    const summaryData = {
        name: `Summary_${new Date().toISOString()}`,
        content: 'New summary content...',
        teacherEmail
    };

    const result = await ipcRenderer.invoke('save-summary', {
        teacherEmail,
        summaryData
    });

    if (result.success) {
        await loadSummaries(teacherEmail);
    }
});

// Logout
logoutBtn.addEventListener('click', () => {
    store.delete('userToken');
    store.delete('userEmail');
    store.delete('userName');
    showLoginScreen();
});

// Initialize the app
async function initializeApp() {
    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        showLoginScreen();
        return;
    }

    teacherEmailElement.textContent = teacherEmail;
    await loadRecordings(teacherEmail);
    await loadSummaries(teacherEmail);
}

initializeApp(); 