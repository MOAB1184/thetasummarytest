const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const Store = require('electron-store');

const store = new Store();

// Create base directory for app data
const appDataPath = path.join(app.getPath('userData'), 'teacher-app-data');
try {
    if (!fs.existsSync(appDataPath)) {
        fs.mkdirSync(appDataPath, { recursive: true });
        console.log('Created app data directory:', appDataPath);
    }

    // Create teachers directory
    const teachersPath = path.join(appDataPath, 'teachers');
    if (!fs.existsSync(teachersPath)) {
        fs.mkdirSync(teachersPath, { recursive: true });
        console.log('Created teachers directory:', teachersPath);
    }
} catch (error) {
    console.error('Error creating directories:', error);
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile('index.html');
  
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Helper function to get teacher directory
function getTeacherDir(teacherEmail) {
    try {
        const teacherDir = path.join(teachersPath, teacherEmail);
        if (!fs.existsSync(teacherDir)) {
            fs.mkdirSync(teacherDir, { recursive: true });
            // Create subdirectories for teacher data
            fs.mkdirSync(path.join(teacherDir, 'recordings'), { recursive: true });
            fs.mkdirSync(path.join(teacherDir, 'summaries'), { recursive: true });
            console.log('Created teacher directory:', teacherDir);
        }
        return teacherDir;
    } catch (error) {
        console.error('Error creating teacher directory:', error);
        throw error;
    }
}

// Handle login
ipcMain.handle('login', async (event, credentials) => {
  try {
    const teacherEmail = credentials.email;
    const teacherDir = getTeacherDir(teacherEmail);
    const teacherDataPath = path.join(teacherDir, 'teacher.json');

    // Create or load teacher data
    let teacherData = {
      email: teacherEmail,
      name: credentials.name || 'Teacher',
      password: credentials.password,
      approved: true,
      created: new Date().toISOString()
    };

    if (fs.existsSync(teacherDataPath)) {
      teacherData = JSON.parse(fs.readFileSync(teacherDataPath, 'utf8'));
      if (teacherData.password !== credentials.password) {
        return { success: false, error: 'Invalid password' };
      }
    } else {
      fs.writeFileSync(teacherDataPath, JSON.stringify(teacherData, null, 2));
    }

    store.set('userToken', 'local-token');
    store.set('userEmail', teacherEmail);
    store.set('userName', teacherData.name);
    return { success: true };
  } catch (error) {
    console.error('Login error:', error);
    return { success: false, error: 'Failed to login' };
  }
});

// Handle class operations
ipcMain.handle('createClass', async (event, { teacherEmail, className }) => {
  try {
    const teacherDir = getTeacherDir(teacherEmail);
    const classesPath = path.join(teacherDir, 'classes');
    const classId = Date.now().toString();
    const classCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    
    const newClass = {
      id: classId,
      name: className,
      code: classCode,
      students: [],
      created: new Date().toISOString()
    };

    fs.writeFileSync(
      path.join(classesPath, `${classId}.json`),
      JSON.stringify(newClass, null, 2)
    );

    return { success: true, class: newClass };
  } catch (error) {
    console.error('Error creating class:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('getClasses', async (event, teacherEmail) => {
  try {
    const teacherDir = getTeacherDir(teacherEmail);
    const classesPath = path.join(teacherDir, 'classes');
    const classes = [];

    if (fs.existsSync(classesPath)) {
      const files = fs.readdirSync(classesPath);
      for (const file of files) {
        if (file.endsWith('.json')) {
          const classData = JSON.parse(fs.readFileSync(path.join(classesPath, file), 'utf8'));
          classes.push(classData);
        }
      }
    }

    return classes;
  } catch (error) {
    console.error('Error getting classes:', error);
    return [];
  }
});

// Handle recording operations
ipcMain.handle('save-recording', async (event, { teacherEmail, recordingData, name }) => {
  try {
    const teacherDir = getTeacherDir(teacherEmail);
    const recordingsPath = path.join(teacherDir, 'recordings');
    const recordingId = Date.now().toString();
    
    const newRecording = {
      id: recordingId,
      name,
      data: recordingData,
      timestamp: new Date().toISOString(),
      duration: 0
    };

    fs.writeFileSync(
      path.join(recordingsPath, `${recordingId}.json`),
      JSON.stringify(newRecording, null, 2)
    );

    return { success: true, recording: newRecording };
  } catch (error) {
    console.error('Error saving recording:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-recordings', async (event, teacherEmail) => {
  try {
    const teacherDir = getTeacherDir(teacherEmail);
    const recordingsPath = path.join(teacherDir, 'recordings');
    const recordings = [];

    if (fs.existsSync(recordingsPath)) {
      const files = fs.readdirSync(recordingsPath);
      for (const file of files) {
        if (file.endsWith('.json')) {
          const recordingData = JSON.parse(fs.readFileSync(path.join(recordingsPath, file), 'utf8'));
          recordings.push(recordingData);
        }
      }
    }

    return recordings;
  } catch (error) {
    console.error('Error getting recordings:', error);
    return [];
  }
});

// Handle summary operations
ipcMain.handle('save-summary', async (event, { teacherEmail, summaryData }) => {
  try {
    const teacherDir = getTeacherDir(teacherEmail);
    const summariesPath = path.join(teacherDir, 'summaries');
    const summaryId = Date.now().toString();
    
    const newSummary = {
      id: summaryId,
      ...summaryData,
      timestamp: new Date().toISOString()
    };

    fs.writeFileSync(
      path.join(summariesPath, `${summaryId}.json`),
      JSON.stringify(newSummary, null, 2)
    );

    return { success: true, summary: newSummary };
  } catch (error) {
    console.error('Error saving summary:', error);
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-summaries', async (event, teacherEmail) => {
  try {
    const teacherDir = getTeacherDir(teacherEmail);
    const summariesPath = path.join(teacherDir, 'summaries');
    const summaries = [];

    if (fs.existsSync(summariesPath)) {
      const files = fs.readdirSync(summariesPath);
      for (const file of files) {
        if (file.endsWith('.json')) {
          const summaryData = JSON.parse(fs.readFileSync(path.join(summariesPath, file), 'utf8'));
          summaries.push(summaryData);
        }
      }
    }

    return summaries;
  } catch (error) {
    console.error('Error getting summaries:', error);
    return [];
  }
}); 