const { ipcRenderer } = require('electron');
const Store = require('electron-store');
const store = new Store();

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const mainScreen = document.getElementById('main-screen');
const loginForm = document.getElementById('login-form');
const teacherNameElement = document.getElementById('teacherName');
const teacherEmailElement = document.getElementById('teacherEmail');
const logoutBtn = document.getElementById('logoutBtn');
const navButtons = document.querySelectorAll('.nav-btn');
const sections = document.querySelectorAll('.section');
const startRecordingBtn = document.getElementById('startRecording');
const stopRecordingBtn = document.getElementById('stopRecording');
const createClassBtn = document.getElementById('createClass');
const classesList = document.getElementById('classesList');
const selectedClassElement = document.getElementById('selectedClass');

// Recording state
let mediaRecorder = null;
let recordingChunks = [];
let recordingTimer = null;
let recordingStartTime = null;
let audioChunks = [];
let currentRecording = null;

// State
let selectedClass = null;

// Event Listeners
loginForm.addEventListener('submit', handleLogin);
logoutBtn.addEventListener('click', handleLogout);
navButtons.forEach(btn => btn.addEventListener('click', handleNavigation));
startRecordingBtn.addEventListener('click', startRecording);
stopRecordingBtn.addEventListener('click', stopRecording);

// Check for existing session
checkSession();

async function checkSession() {
    const token = store.get('userToken');
    if (token) {
        showMainScreen();
        loadUserData();
    }
}

async function handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    try {
        console.log('Attempting login...');
        
        // Check for admin credentials first
        if (email === 'admin' && password === 'duggy') {
            store.set('userEmail', 'admin@example.com');
            store.set('userRole', 'admin');
            store.set('userName', 'Admin');
            showMainScreen();
            loadUserData();
            return;
        }

        // For regular teachers, check Wasabi storage
        try {
            const userData = await ipcRenderer.invoke('get-user-data', { email });
            
            if (!userData) {
                showError('User not found');
                return;
            }

            if (userData.password !== password) {
                showError('Invalid password');
                return;
            }

            if (userData.role !== 'teacher') {
                showError('This account is not a teacher account');
                return;
            }

            if (!userData.approved) {
                showError('Your teacher account is pending approval');
                return;
            }

            // Store user info
            store.set('userEmail', userData.email);
            store.set('userRole', 'teacher');
            store.set('userName', userData.name);

            console.log('Login successful, showing main screen...');
            showMainScreen();
            loadUserData();
        } catch (error) {
            console.error('Teacher login error:', error);
            showError('Failed to verify teacher credentials');
        }
    } catch (error) {
        console.error('Login error:', error);
        showError('An error occurred during login. Please try again.');
    }
}

function handleLogout() {
    console.log('Logging out...');
    // Clear all session data
    store.delete('userEmail');
    store.delete('userRole');
    store.delete('userName');
    
    // Clear main process store via IPC
    ipcRenderer.invoke('clear-store');
    
    // Reset form
    document.getElementById('login-form').reset();
    
    showLoginScreen();
}

function handleNavigation(e) {
    const section = e.target.dataset.section;
    showSection(section);
}

function showSection(sectionId) {
    sections.forEach(section => {
        section.style.display = section.id === sectionId ? 'block' : 'none';
    });
    
    navButtons.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.section === sectionId);
    });

    // Only load classes data when showing classes section
    if (sectionId === 'classes') {
        loadClasses();
    }
}

function showMainScreen() {
    loginScreen.style.display = 'none';
    mainScreen.style.display = 'block';
    showSection('classes'); // Start with classes section instead of recordings
}

function showLoginScreen() {
    loginScreen.style.display = 'block';
    mainScreen.style.display = 'none';
}

async function loadUserData() {
    const email = store.get('userEmail');
    const name = store.get('userName');
    const role = store.get('userRole');
    
    // Update profile information
    document.getElementById('profileName').textContent = name;
    document.getElementById('profileEmail').textContent = email;
    document.getElementById('profileRole').textContent = role.charAt(0).toUpperCase() + role.slice(1);
    
    // Update teacher name display
    document.getElementById('teacherNameDisplay').textContent = name;
    
    // Load classes
    await loadClasses();
}

function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;
    
    // Remove any existing error messages
    const existingErrors = document.querySelectorAll('.error-message');
    existingErrors.forEach(err => err.remove());
    
    // Add the new error message
    const form = document.getElementById('login-form');
    form.insertBefore(errorDiv, form.firstChild);
    
    // Scroll to the error message
    errorDiv.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function startRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];
        recordingStartTime = Date.now();

        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };

        mediaRecorder.onstop = async () => {
            const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
            const teacherEmail = store.get('userEmail');
            const recordingName = `Recording_${new Date().toISOString()}`;
            const duration = Math.floor((Date.now() - recordingStartTime) / 1000);
            
            const result = await ipcRenderer.invoke('save-recording', {
                teacherEmail,
                className: selectedClass.name,
                recordingData: await blobToBase64(audioBlob),
                name: recordingName,
                duration: duration
            });

            if (result.success) {
                await loadRecordings();
                stopRecordingTimer();
            }
        };

        mediaRecorder.start();
        startRecordingBtn.disabled = true;
        stopRecordingBtn.disabled = false;
        startRecordingTimer();
    } catch (error) {
        console.error('Error starting recording:', error);
    }
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        startRecordingBtn.disabled = false;
        stopRecordingBtn.disabled = true;
        stopRecordingTimer();
    }
}

function startRecordingTimer() {
    const timerElement = document.getElementById('recordingTimer');
    timerElement.classList.add('recording');
    recordingTimer = setInterval(() => {
        const elapsed = Math.floor((Date.now() - recordingStartTime) / 1000);
        timerElement.textContent = formatTime(elapsed);
    }, 1000);
}

function stopRecordingTimer() {
    clearInterval(recordingTimer);
    const timerElement = document.getElementById('recordingTimer');
    timerElement.classList.remove('recording');
    timerElement.textContent = '00:00';
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}

async function saveRecording(blob) {
    try {
        const reader = new FileReader();
        reader.readAsDataURL(blob);
        reader.onloadend = async () => {
            const recordingData = {
                data: reader.result,
                timestamp: new Date().toISOString(),
                duration: Math.floor((Date.now() - recordingStartTime) / 1000)
            };
            await ipcRenderer.invoke('saveRecording', recordingData);
            loadUserData(); // Reload recordings list
        };
    } catch (error) {
        console.error('Error saving recording:', error);
        alert('Failed to save recording');
    }
}

function renderClasses(classes) {
    if (!classes || classes.length === 0) {
        classesList.innerHTML = `
            <div class="empty-state">
                <p>No classes yet. Create your first class to get started!</p>
                <button onclick="showCreateClassForm()">Create Class</button>
            </div>
        `;
        return;
    }

    classesList.innerHTML = classes.map(cls => `
        <div class="class-item" onclick="selectClass('${cls.code}')">
            <div class="class-header">
                <h3>${cls.name}</h3>
                <span class="class-code">Code: ${cls.code}</span>
            </div>
            <div class="class-info">
                <div class="student-count">
                    <span>${cls.students.length} Students</span>
                    ${cls.pendingStudents.length > 0 ? 
                        `<span class="pending-badge">${cls.pendingStudents.length} pending</span>` : 
                        ''}
                </div>
                <span class="class-date">Created: ${new Date(cls.createdAt).toLocaleDateString()}</span>
            </div>
            <div class="class-actions">
                <button onclick="viewClassDetails('${cls.code}')">View Details</button>
            </div>
        </div>
    `).join('');
}

function renderRecordings(recordings) {
    if (!recordings || recordings.length === 0) {
        recordingsList.innerHTML = '<div class="recording-item">No recordings yet</div>';
        return;
    }
    
    recordingsList.innerHTML = recordings.map(recording => `
        <div class="recording-item">
            <div class="recording-info">
                <span class="recording-name">${recording.name || 'Unnamed Recording'}</span>
                <div class="recording-details">
                    <span class="recording-date">${new Date(recording.timestamp).toLocaleString()}</span>
                    <span class="recording-duration">Duration: ${formatTime(recording.duration || 0)}</span>
                </div>
            </div>
            <button onclick="playRecording('${recording.id}')">Play</button>
        </div>
    `).join('');
}

function renderSummaries(summaries) {
    if (!summaries || summaries.length === 0) {
        summariesList.innerHTML = '<div class="summary-item">No summaries available</div>';
        return;
    }
    
    summariesList.innerHTML = summaries.map(summary => `
        <div class="summary-item">
            <div class="summary-info">
                <span class="summary-name">${summary.name || 'Unnamed Summary'}</span>
                <span class="summary-date">${new Date(summary.timestamp).toLocaleString()}</span>
            </div>
            <div class="summary-content">${summary.content || 'No content'}</div>
        </div>
    `).join('');
}

function showCreateClassForm() {
    const form = document.createElement('div');
    form.className = 'create-class-form';
    form.innerHTML = `
        <h3>Create New Class</h3>
        <div class="form-group">
            <label for="className">Class Name</label>
            <input type="text" id="className" required placeholder="Enter class name">
        </div>
        <div class="form-actions">
            <button onclick="createClass()">Create</button>
            <button onclick="cancelCreateClass()" class="secondary-button">Cancel</button>
        </div>
    `;

    const existingForm = document.querySelector('.create-class-form');
    if (existingForm) {
        existingForm.remove();
    }

    classesList.insertBefore(form, classesList.firstChild);
}

async function createClass() {
    const className = document.getElementById('className').value;
    if (!className) {
        showError('Please enter a class name');
        return;
    }

    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        showError('No teacher email found');
        return;
    }

    try {
        const result = await ipcRenderer.invoke('create-class', {
            teacherEmail,
            className
        });

        if (result.success) {
            document.querySelector('.create-class-form').remove();
            await loadClasses();
        } else {
            showError(result.error || 'Failed to create class');
        }
    } catch (error) {
        console.error('Error creating class:', error);
        showError('Failed to create class');
    }
}

function cancelCreateClass() {
    document.querySelector('.create-class-form').remove();
}

async function selectClass(classCode) {
    const teacherEmail = store.get('userEmail');
    const classes = await ipcRenderer.invoke('get-classes', { teacherEmail });
    selectedClass = classes.find(c => c.code === classCode);
    
    if (selectedClass) {
        selectedClassElement.textContent = `Selected Class: ${selectedClass.name}`;
        await loadRecordings();
        await loadSummaries();
        showPendingStudents();
    }
}

function showPendingStudents() {
    if (!selectedClass || !selectedClass.pendingStudents.length) {
        return;
    }

    const pendingList = document.createElement('div');
    pendingList.className = 'pending-students';
    pendingList.innerHTML = `
        <h3>Pending Students</h3>
        ${selectedClass.pendingStudents.map(student => `
            <div class="pending-student">
                <div class="student-info">
                    <span>${student.name}</span>
                    <span>${student.email}</span>
                </div>
                <div class="student-actions">
                    <button onclick="approveStudent('${student.email}')">Approve</button>
                    <button onclick="denyStudent('${student.email}')" class="deny-button">Deny</button>
                </div>
            </div>
        `).join('')}
    `;

    const existingList = document.querySelector('.pending-students');
    if (existingList) {
        existingList.remove();
    }

    classesList.insertBefore(pendingList, classesList.firstChild);
}

async function approveStudent(studentEmail) {
    if (!selectedClass) return;

    const teacherEmail = store.get('userEmail');
    try {
        const result = await ipcRenderer.invoke('approve-student', {
            teacherEmail,
            classCode: selectedClass.code,
            studentEmail
        });

        if (result.success) {
            selectedClass = result.class;
            showPendingStudents();
            await loadClasses();
        }
    } catch (error) {
        console.error('Error approving student:', error);
        showError('Failed to approve student');
    }
}

async function denyStudent(studentEmail) {
    if (!selectedClass) return;

    const teacherEmail = store.get('userEmail');
    try {
        const result = await ipcRenderer.invoke('deny-student', {
            teacherEmail,
            classCode: selectedClass.code,
            studentEmail
        });

        if (result.success) {
            selectedClass = result.class;
            showPendingStudents();
            await loadClasses();
        }
    } catch (error) {
        console.error('Error denying student:', error);
        showError('Failed to deny student');
    }
}

async function viewClassDetails(classCode) {
    const teacherEmail = store.get('userEmail');
    const classes = await ipcRenderer.invoke('get-classes', { teacherEmail });
    selectedClass = classes.find(c => c.code === classCode);
    
    if (selectedClass) {
        // Show class details section
        document.getElementById('classDetails').style.display = 'block';
        document.getElementById('classes').style.display = 'none';
        
        // Update class details header
        document.getElementById('selectedClass').textContent = `Class: ${selectedClass.name}`;
        
        // Load class-specific data
        await loadRecordings();
        await loadSummaries();
        showPendingStudents();
    }
}

// Tab navigation
document.querySelectorAll('.tab-btn').forEach(button => {
    button.addEventListener('click', () => {
        const tabId = button.dataset.tab;
        switchTab(tabId);
    });
});

function switchTab(tabId) {
    // Update active tab button
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabId);
    });

    // Show active tab content
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.toggle('active', pane.id === `${tabId}-tab`);
    });
}

function backToClasses() {
    document.getElementById('classDetails').style.display = 'none';
    document.getElementById('classes').style.display = 'block';
    selectedClass = null;
}

// Navigation
navButtons.forEach(button => {
    button.addEventListener('click', () => {
        const section = button.dataset.section;
        
        // Update active button
        navButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Show selected section
        sections.forEach(s => {
            s.classList.remove('active');
            if (s.id === `${section}-section`) {
                s.classList.add('active');
            }
        });
    });
});

// Logout
logoutBtn.addEventListener('click', () => {
    store.delete('userToken');
    store.delete('userEmail');
    store.delete('userName');
    showLoginScreen();
});

// Initialize the app
async function initializeApp() {
    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        showLoginScreen();
        return;
    }

    teacherEmailElement.textContent = teacherEmail;
    await loadRecordings(teacherEmail);
    await loadSummaries(teacherEmail);
}

initializeApp();

async function handleSaveRecording() {
    try {
        console.log('Starting recording save process...');
        const userEmail = await window.electron.getUserEmail();
        if (!userEmail) {
            throw new Error('No user email found');
        }

        const recordingData = {
            // ... existing recording data ...
        };

        console.log('Sending recording to main process...');
        const result = await window.electron.saveRecording({
            teacherEmail: userEmail,
            recordingData,
            name: document.getElementById('recordingName').value
        });

        if (result.success) {
            console.log('Recording saved successfully');
            showSuccess('Recording saved successfully');
        } else {
            console.error('Failed to save recording:', result.error);
            showError(result.error || 'Failed to save recording');
        }
    } catch (error) {
        console.error('Recording save error:', error);
        showError('An error occurred while saving the recording');
    }
}

async function loadClasses() {
    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        console.error('No teacher email found');
        return;
    }

    const classes = await ipcRenderer.invoke('get-classes', { teacherEmail });
    renderClasses(classes);
}

async function loadRecordings(teacherEmail) {
    if (!teacherEmail || !selectedClass) {
        console.error('No teacher email or class selected');
        return;
    }

    const recordings = await ipcRenderer.invoke('get-recordings', { 
        teacherEmail,
        classCode: selectedClass.code
    });

    if (!recordings || recordings.length === 0) {
        recordingsList.innerHTML = '<div class="recording-item">No recordings yet</div>';
        return;
    }

    recordingsList.innerHTML = recordings.map(recording => `
        <div class="recording-item">
            <div class="recording-info">
                <span class="recording-name">${recording.name}</span>
                <div class="recording-details">
                    <span class="recording-date">${new Date(recording.timestamp).toLocaleString()}</span>
                    <span class="recording-duration">Duration: ${formatTime(recording.duration || 0)}</span>
                </div>
            </div>
            <button onclick="playRecording('${recording.id}')">Play</button>
        </div>
    `).join('');
}

async function loadSummaries(teacherEmail) {
    if (!teacherEmail || !selectedClass) {
        console.error('No teacher email or class selected');
        return;
    }

    const summaries = await ipcRenderer.invoke('get-summaries', { 
        teacherEmail,
        classCode: selectedClass.code
    });

    if (!summaries || summaries.length === 0) {
        summariesList.innerHTML = '<div class="summary-item">No summaries available</div>';
        return;
    }

    summariesList.innerHTML = summaries.map(summary => `
        <div class="summary-item">
            <div class="summary-info">
                <span class="summary-name">${summary.name}</span>
                <span class="summary-date">${new Date(summary.timestamp).toLocaleString()}</span>
            </div>
            <div class="summary-content">${summary.content}</div>
        </div>
    `).join('');
}

async function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
    });
}

// Navigation
navButtons.forEach(button => {
    button.addEventListener('click', () => {
        const section = button.dataset.section;
        
        // Update active button
        navButtons.forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        // Show selected section
        sections.forEach(s => {
            s.classList.remove('active');
            if (s.id === `${section}-section`) {
                s.classList.add('active');
            }
        });
    });
});

// Logout
logoutBtn.addEventListener('click', () => {
    store.delete('userToken');
    store.delete('userEmail');
    store.delete('userName');
    showLoginScreen();
});

// Initialize the app
async function initializeApp() {
    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        showLoginScreen();
        return;
    }

    teacherEmailElement.textContent = teacherEmail;
    await loadRecordings(teacherEmail);
    await loadSummaries(teacherEmail);
}

initializeApp();

async function handleSaveRecording() {
    try {
        console.log('Starting recording save process...');
        const userEmail = await window.electron.getUserEmail();
        if (!userEmail) {
            throw new Error('No user email found');
        }

        const recordingData = {
            // ... existing recording data ...
        };

        console.log('Sending recording to main process...');
        const result = await window.electron.saveRecording({
            teacherEmail: userEmail,
            recordingData,
            name: document.getElementById('recordingName').value
        });

        if (result.success) {
            console.log('Recording saved successfully');
            showSuccess('Recording saved successfully');
        } else {
            console.error('Failed to save recording:', result.error);
            showError(result.error || 'Failed to save recording');
        }
    } catch (error) {
        console.error('Recording save error:', error);
        showError('An error occurred while saving the recording');
    }
}

async function loadClasses() {
    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        console.error('No teacher email found');
        return;
    }

    const classes = await ipcRenderer.invoke('get-classes', { teacherEmail });
    renderClasses(classes);
}

async function createClass() {
    const className = document.getElementById('className').value;
    if (!className) {
        showError('Please enter a class name');
        return;
    }

    const teacherEmail = store.get('userEmail');
    if (!teacherEmail) {
        showError('No teacher email found');
        return;
    }

    try {
        const result = await ipcRenderer.invoke('create-class', {
            teacherEmail,
            className
        });

        if (result.success) {
            document.querySelector('.create-class-form').remove();
            await loadClasses();
        } else {
            showError(result.error || 'Failed to create class');
        }
    } catch (error) {
        console.error('Error creating class:', error);
        showError('Failed to create class');
    }
}

function cancelCreateClass() {
    document.querySelector('.create-class-form').remove();
}

async function selectClass(classCode) {
    const teacherEmail = store.get('userEmail');
    const classes = await ipcRenderer.invoke('get-classes', { teacherEmail });
    selectedClass = classes.find(c => c.code === classCode);
    
    if (selectedClass) {
        selectedClassElement.textContent = `Selected Class: ${selectedClass.name}`;
        await loadRecordings();
        await loadSummaries();
        showPendingStudents();
    }
}

function showPendingStudents() {
    if (!selectedClass || !selectedClass.pendingStudents.length) {
        return;
    }

    const pendingList = document.createElement('div');
    pendingList.className = 'pending-students';
    pendingList.innerHTML = `
        <h3>Pending Students</h3>
        ${selectedClass.pendingStudents.map(student => `
            <div class="pending-student">
                <div class="student-info">
                    <span>${student.name}</span>
                    <span>${student.email}</span>
                </div>
                <div class="student-actions">
                    <button onclick="approveStudent('${student.email}')">Approve</button>
                    <button onclick="denyStudent('${student.email}')" class="deny-button">Deny</button>
                </div>
            </div>
        `).join('')}
    `;

    const existingList = document.querySelector('.pending-students');
    if (existingList) {
        existingList.remove();
    }

    classesList.insertBefore(pendingList, classesList.firstChild);
}

async function approveStudent(studentEmail) {
    if (!selectedClass) return;

    const teacherEmail = store.get('userEmail');
    try {
        const result = await ipcRenderer.invoke('approve-student', {
            teacherEmail,
            classCode: selectedClass.code,
            studentEmail
        });

        if (result.success) {
            selectedClass = result.class;
            showPendingStudents();
            await loadClasses();
        }
    } catch (error) {
        console.error('Error approving student:', error);
        showError('Failed to approve student');
    }
}

async function denyStudent(studentEmail) {
    if (!selectedClass) return;

    const teacherEmail = store.get('userEmail');
    try {
        const result = await ipcRenderer.invoke('deny-student', {
            teacherEmail,
            classCode: selectedClass.code,
            studentEmail
        });

        if (result.success) {
            selectedClass = result.class;
            showPendingStudents();
            await loadClasses();
        }
    } catch (error) {
        console.error('Error denying student:', error);
        showError('Failed to deny student');
    }
}

async function viewClassDetails(classCode) {
    const teacherEmail = store.get('userEmail');
    const classes = await ipcRenderer.invoke('get-classes', { teacherEmail });
    selectedClass = classes.find(c => c.code === classCode);
    
    if (selectedClass) {
        // Show class details section
        document.getElementById('classDetails').style.display = 'block';
        document.getElementById('classes').style.display = 'none';
        
        // Update class details header
        document.getElementById('selectedClass').textContent = `Class: ${selectedClass.name}`;
        
        // Load class-specific data
        await loadRecordings();
        await loadSummaries();
        showPendingStudents();
    }
}

// Tab navigation
document.querySelectorAll('.tab-btn').forEach(button => {
    button.addEventListener('click', () => {
        const tabId = button.dataset.tab;
        switchTab(tabId);
    });
});

function switchTab(tabId) {
    // Update active tab button
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabId);
    });

    // Show active tab content
    document.querySelectorAll('.tab-pane').forEach(pane => {
        pane.classList.toggle('active', pane.id === `${tabId}-tab`);
    });
}

function backToClasses() {
    document.getElementById('classDetails').style.display = 'none';
    document.getElementById('classes').style.display = 'block';
    selectedClass = null;
} 