Teacher App Installation Guide

1. Extract all files from this zip to a folder
2. Double-click the "start-app.bat" file
3. The app will install and start automatically
4. A desktop shortcut will be created for easy access

If you encounter any issues:
- Make sure you have an internet connection
- Try running the app again by double-clicking start-app.bat
- Contact technical support if problems persist

Note: The first time you run the app, Windows may show a security warning.
Click "More info" and then "Run anyway" to proceed.