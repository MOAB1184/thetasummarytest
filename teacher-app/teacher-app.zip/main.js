const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const Store = require('electron-store');
const AWS = require('aws-sdk');
require('dotenv').config();

console.log('\n=== Teacher App Initialization ===');
console.log('Initializing AWS S3 client with config:', {
    endpoint: 'https://s3.us-west-1.wasabisys.com',
    region: 'us-west-1',
    accessKeyId: process.env.WASABI_ACCESS_KEY,
    secretAccessKey: process.env.WASABI_SECRET_KEY?.slice(0, 4) + '...',
    s3ForcePathStyle: true
});

const store = new Store();

// Configure AWS for Wasabi - match site's configuration exactly
const s3 = new AWS.S3({
    endpoint: 'https://s3.us-west-1.wasabisys.com',
    accessKeyId: process.env.WASABI_ACCESS_KEY,
    secretAccessKey: process.env.WASABI_SECRET_KEY,
    region: 'us-west-1',
    s3ForcePathStyle: true
});

console.log('AWS S3 client initialized successfully');

// Create base directory for app data
const appDataPath = path.join(app.getPath('userData'), 'teacher-app-data');
try {
    if (!fs.existsSync(appDataPath)) {
        fs.mkdirSync(appDataPath, { recursive: true });
        console.log('Created app data directory:', appDataPath);
    }

    // Create temporary directories for recordings and summaries
    const recordingsPath = path.join(appDataPath, 'recordings');
    const summariesPath = path.join(appDataPath, 'summaries');
    
    if (!fs.existsSync(recordingsPath)) {
        fs.mkdirSync(recordingsPath, { recursive: true });
    }
    if (!fs.existsSync(summariesPath)) {
        fs.mkdirSync(summariesPath, { recursive: true });
    }
} catch (error) {
    console.error('\n=== Directory Creation Error ===');
    console.error('Error type:', error.constructor.name);
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
}

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false
    }
  });

  mainWindow.loadFile('index.html');
  
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Update all bucket references
const BUCKET_NAME = process.env.WASABI_BUCKET;

// Handle store clearing
ipcMain.handle('clear-store', () => {
  console.log('Clearing main process store...');
  store.clear();
  return true;
});

// Handle user data retrieval for login
ipcMain.handle('get-user-data', async (event, params) => {
    if (!params || !params.email) {
        console.error('Missing email parameter for get-user-data');
        return null;
    }

    try {
        console.log('\n=== Getting User Data ===');
        console.log('Email:', params.email);

        const userData = await s3.getObject({
            Bucket: BUCKET_NAME,
            Key: `users/${params.email}.json`
        }).promise().then(data => JSON.parse(data.Body.toString()));

        console.log('User data retrieved successfully');
        return userData;
    } catch (error) {
        if (error.code === 'NoSuchKey') {
            console.log('User not found:', params.email);
            return null;
        }
        console.error('Error getting user data:', error);
        throw error;
    }
});

// Handle recording operations
ipcMain.handle('save-recording', async (event, params) => {
    if (!params || !params.teacherEmail || !params.className) {
        console.error('Missing required parameters for save-recording');
        return { success: false, error: 'Missing required parameters' };
    }

    try {
        console.log('\n=== Starting Recording Save ===');
        console.log('Save parameters:', {
            teacherEmail: params.teacherEmail,
            className: params.className,
            name: params.name,
            dataSize: params.recordingData?.length
        });

        const recordingId = Date.now().toString();
        const recordingKey = `teachers/${params.teacherEmail}/${params.className}/recordings/${recordingId}.json`;
        
        const newRecording = {
            id: recordingId,
            name: params.name,
            data: params.recordingData,
            timestamp: new Date().toISOString(),
            duration: params.duration || 0
        };

        console.log('Preparing S3 upload...');
        const uploadParams = {
            Bucket: BUCKET_NAME,
            Key: recordingKey,
            Body: JSON.stringify(newRecording),
            ContentType: 'application/json'
        };

        console.log('Initiating S3 upload...');
        const result = await s3.upload(uploadParams).promise();
        console.log('Upload successful:', {
            key: recordingKey,
            location: result.Location,
            etag: result.ETag
        });

        return { success: true, recording: newRecording };
    } catch (error) {
        console.error('\n=== Recording Save Error ===');
        console.error('Error type:', error.constructor.name);
        console.error('Error code:', error.code);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('get-recordings', async (event, params) => {
    if (!params || !params.teacherEmail || !params.className) {
        console.error('Missing required parameters for get-recordings');
        return [];
    }

    try {
        console.log('Getting recordings for teacher:', params.teacherEmail, 'class:', params.className);
        const listParams = {
            Bucket: BUCKET_NAME,
            Prefix: `teachers/${params.teacherEmail}/${params.className}/recordings/`
        };

        const data = await s3.listObjectsV2(listParams).promise();
        const recordings = [];

        for (const obj of data.Contents) {
            if (obj.Key.endsWith('.json')) {
                const recordingData = await s3.getObject({
                    Bucket: BUCKET_NAME,
                    Key: obj.Key
                }).promise();
                
                recordings.push(JSON.parse(recordingData.Body.toString()));
            }
        }

        console.log('Total recordings loaded:', recordings.length);
        return recordings;
    } catch (error) {
        console.error('Error getting recordings:', error);
        return [];
    }
});

// Handle summary operations
ipcMain.handle('save-summary', async (event, { teacherEmail, className, summaryData }) => {
    try {
        const summaryId = Date.now().toString();
        const summaryKey = `teachers/${teacherEmail}/${className}/summaries/${summaryId}.txt`;
        
        // Save the summary content as a .txt file
        await s3.putObject({
            Bucket: BUCKET_NAME,
            Key: summaryKey,
            Body: summaryData.content,
            ContentType: 'text/plain'
        }).promise();

        // Save metadata separately
        const metadataKey = `teachers/${teacherEmail}/${className}/summaries/${summaryId}.json`;
        const metadata = {
            id: summaryId,
            name: summaryData.name,
            timestamp: new Date().toISOString()
        };

        await s3.putObject({
            Bucket: BUCKET_NAME,
            Key: metadataKey,
            Body: JSON.stringify(metadata),
            ContentType: 'application/json'
        }).promise();

        return { success: true, summary: { ...metadata, content: summaryData.content } };
    } catch (error) {
        console.error('Error saving summary:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('get-summaries', async (event, { teacherEmail, className }) => {
    try {
        console.log('Getting summaries for teacher:', teacherEmail, 'class:', className);
        const params = {
            Bucket: BUCKET_NAME,
            Prefix: `teachers/${teacherEmail}/${className}/summaries/`
        };

        const data = await s3.listObjectsV2(params).promise();
        const summaries = [];

        // First get all metadata files
        const metadataFiles = data.Contents.filter(obj => obj.Key.endsWith('.json'));
        
        for (const metadataFile of metadataFiles) {
            // Get metadata
            const metadataData = await s3.getObject({
                Bucket: BUCKET_NAME,
                Key: metadataFile.Key
            }).promise();
            
            const metadata = JSON.parse(metadataData.Body.toString());
            
            // Get corresponding content file
            const contentKey = metadataFile.Key.replace('.json', '.txt');
            const contentData = await s3.getObject({
                Bucket: BUCKET_NAME,
                Key: contentKey
            }).promise();
            
            summaries.push({
                ...metadata,
                content: contentData.Body.toString()
            });
        }

        console.log('Total summaries loaded:', summaries.length);
        return summaries;
    } catch (error) {
        console.error('Error getting summaries:', error);
        return [];
    }
});

// Handle class operations
ipcMain.handle('create-class', async (event, params) => {
    if (!params || !params.teacherEmail || !params.className) {
        console.error('Missing required parameters for create-class');
        return { success: false, error: 'Missing required parameters' };
    }

    try {
        console.log('\n=== Creating New Class ===');
        console.log('Parameters:', {
            teacherEmail: params.teacherEmail,
            className: params.className
        });

        // Generate a unique 6-character class code
        const generateClassCode = () => {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
            let code = '';
            for (let i = 0; i < 6; i++) {
                code += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return code;
        };

        const classCode = generateClassCode();
        const classKey = `teachers/${params.teacherEmail}/${classCode}/info.json`;
        
        const classData = {
            name: params.className,
            code: classCode,
            teacherEmail: params.teacherEmail,
            createdAt: new Date().toISOString(),
            students: [],
            pendingStudents: []
        };

        console.log('Saving class data...');
        await s3.putObject({
            Bucket: BUCKET_NAME,
            Key: classKey,
            Body: JSON.stringify(classData),
            ContentType: 'application/json'
        }).promise();

        console.log('Class created successfully:', classData);
        return { success: true, class: classData };
    } catch (error) {
        console.error('Error creating class:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('get-classes', async (event, params) => {
    if (!params || !params.teacherEmail) {
        console.error('Missing required parameters for get-classes');
        return [];
    }

    try {
        console.log('Getting classes for teacher:', params.teacherEmail);
        const listParams = {
            Bucket: BUCKET_NAME,
            Prefix: `teachers/${params.teacherEmail}/`
        };

        const data = await s3.listObjectsV2(listParams).promise();
        const classes = [];

        for (const obj of data.Contents) {
            if (obj.Key.endsWith('info.json')) {
                const classData = await s3.getObject({
                    Bucket: BUCKET_NAME,
                    Key: obj.Key
                }).promise();
                
                classes.push(JSON.parse(classData.Body.toString()));
            }
        }

        console.log('Total classes loaded:', classes.length);
        return classes;
    } catch (error) {
        console.error('Error getting classes:', error);
        return [];
    }
});

ipcMain.handle('approve-student', async (event, params) => {
    if (!params || !params.teacherEmail || !params.classCode || !params.studentEmail) {
        console.error('Missing required parameters for approve-student');
        return { success: false, error: 'Missing required parameters' };
    }

    try {
        console.log('\n=== Approving Student ===');
        console.log('Parameters:', params);

        const classKey = `teachers/${params.teacherEmail}/classes/${params.classCode}/info.json`;
        
        // Get current class data
        const classData = await s3.getObject({
            Bucket: BUCKET_NAME,
            Key: classKey
        }).promise().then(data => JSON.parse(data.Body.toString()));

        // Remove from pending and add to approved students
        classData.pendingStudents = classData.pendingStudents.filter(s => s.email !== params.studentEmail);
        const studentToApprove = classData.pendingStudents.find(s => s.email === params.studentEmail);
        if (studentToApprove) {
            classData.students.push(studentToApprove);
        }

        // Save updated class data
        await s3.putObject({
            Bucket: BUCKET_NAME,
            Key: classKey,
            Body: JSON.stringify(classData),
            ContentType: 'application/json'
        }).promise();

        console.log('Student approved successfully');
        return { success: true, class: classData };
    } catch (error) {
        console.error('Error approving student:', error);
        return { success: false, error: error.message };
    }
});

ipcMain.handle('deny-student', async (event, params) => {
    if (!params || !params.teacherEmail || !params.classCode || !params.studentEmail) {
        console.error('Missing required parameters for deny-student');
        return { success: false, error: 'Missing required parameters' };
    }

    try {
        console.log('\n=== Denying Student ===');
        console.log('Parameters:', params);

        const classKey = `teachers/${params.teacherEmail}/classes/${params.classCode}/info.json`;
        
        // Get current class data
        const classData = await s3.getObject({
            Bucket: BUCKET_NAME,
            Key: classKey
        }).promise().then(data => JSON.parse(data.Body.toString()));

        // Remove from pending students
        classData.pendingStudents = classData.pendingStudents.filter(s => s.email !== params.studentEmail);

        // Save updated class data
        await s3.putObject({
            Bucket: BUCKET_NAME,
            Key: classKey,
            Body: JSON.stringify(classData),
            ContentType: 'application/json'
        }).promise();

        console.log('Student denied successfully');
        return { success: true, class: classData };
    } catch (error) {
        console.error('Error denying student:', error);
        return { success: false, error: error.message };
    }
}); 